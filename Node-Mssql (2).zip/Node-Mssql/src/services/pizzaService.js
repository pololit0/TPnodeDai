
import sql from 'mssql';
import configDB from '../models/db.js';
import Pizza from '../models/pizza.js';

export const getPizzas = async () => {
    const conn = await sql.connect(configDB);
    console.log("a");
    const results = await conn.request().query('SELECT * FROM Pizzas');
    
    console.log(results);
    return results
}


export const getPizzasById = async (id) => {
    const conn = await sql.connect(configDB);
    const results = await conn.request().input("pId",sql.Int, id).query('SELECT * FROM Pizzas where Id = @pId');
    
    //console.log(results);
    return results
}

export const CreatePizza= async(pizza) =>
{ const conn = await sql.connect(configDB);
    const results= await conn.request()
    .input("pNombre", sql.VarChar(150), pizza.nombre)
    .input("pDescripcion", sql.VarChar(150), pizza.descripcion)
    .input("pLibreDeGluten", sql.Bit,pizza.libreDeGluten)
    .input("pPrecio", sql.Float, pizza.precio)
    .query('INSERT INTO Pizzas(Nombre, Descripcion, Importe, LibreGluten) VALUES (@pNombre, @pDescripcion, @pPrecio, @pLibreDeGluten)');
    
    return results;

}

export const UpdatePizza = async (pizza, id) =>{
    const conn = await sql.connect(configDB);
    const results = await conn.request()
    .input("pId",id)
    .input("pNombre", pizza.nombre)
    .input("pLibreDeGluten", pizza.libreDeGluten)
    .input("pImporte", pizza.precio)
    .input("pDescripcion", pizza.descripcion)
    .query('UPDATE Pizzas SET Nombre = @pNombre, LibreGluten = @pLibreDeGluten, Importe = @pImporte, Descripcion = @pDescripcion WHERE Id = @pId');
   
    return results;
}

export const DeletePizzas = async (id) => {
    const conn = await sql.connect(configDB);
    const results = await conn.request().input("pId", id ).query('Delete FROM Pizzas where Id= @pId');

    console.log(results);
    return results;
}
