import Pizza from "./models/pizza.js";
import  express  from "express";
import { CreatePizza,UpdatePizza,getPizzas,getPizzasById,DeletePizzas } from "./services/pizzaService.js";



const app = express();
const port = 3000;

app.use(express.json());

app.post('/api/Create', async (req,res)=>{

    const pizza = new Pizza();

    pizza.nombre = req.body.nombre
    pizza.descripcion =req.body.descripcion
    pizza.libreDeGluten=req.body.LibreDeGluten
    pizza.precio = req.body.precio
    const CrearPizza= await CreatePizza(pizza)
    res.status(201).json(CrearPizza);
})

app.put('/api/:id', async (req,res)=>{
    const id = req.params.id
    
     if(id <=0)
    {
        res.status(400).json({ error: 'tenes que ingresar un id mas grande que 0 :(' }).send();
        return
    } 
    const pizza = new Pizza()
    pizza.nombre = req.body.nombre
    pizza.descripcion =req.body.descripcion
    pizza.libreDeGluten=req.body.LibreDeGluten
    pizza.precio = req.body.precio
   
    const Update= await UpdatePizza(pizza,id)
    if
    (Update.rowsAffected==0 ) {
        res.status(404).json({ error: ' La pizza que queres acutualizar no existe :(' }).send();
        return
      } else
    {    
        res.status(200).json(Update);   
        return
    }
   
 
})


app.get('/api/:id', async (req,res)=>{
    
    const id = req.params.id
    if(id <=0)
    {
        res.status(400).json({ error: 'tenes que ingresar un id mas grande que 0 :(' }).send();
        return
    } 
    const traerPizza= await getPizzasById(id)
    console.log(traerPizza);
    if(traerPizza.recordset.length === 0) {
        console.log("a");

        res.status(404).json({ error: ' La pizza que queres mostrar no existe :(' }).send();
        return
    } 
    else
    {  
        res.status(200).json(traerPizza);   
    }
   
})

app.get('/api',  async (req, res)=> {
    console.log("b");
    const traerTodas = await getPizzas();
    res.status(200).send(traerTodas)
});


   app.delete('/api/:id', async (req,res)=>{
    const id = req.params.id;
    
    if(id < 1){
        res.status(400).json({ error: 'tenes que ingresar un id mas grande que 0 :(' }).send();
        return;
    }
    const  borrar  = await DeletePizzas(id);
    console.log(borrar);
    if(borrar.rowsAffected == 0){
        res.status(404).json({ error: ' La pizza que queres borrar no existe :(' }).send();
        return;
    }
    res.status(200).json(borrar);
   })


app.listen(port, ()=>{

    console.log('puerto: ${port}')
})