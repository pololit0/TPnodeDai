const config = {
    user: 'Pizzas',
    password: 'Pizzas',
    server: 'A-PHZ2-AMI-008',
    database: 'DAI-Pizzas',
    options: {
        trustServerCertificate: true,
        trustedConnection: true,
    }
}

export default config;
