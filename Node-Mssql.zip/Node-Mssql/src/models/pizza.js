export default class Pizza {
    id;
    descripcion;
    nombre;
    precio;
    libreDeGluten;
}