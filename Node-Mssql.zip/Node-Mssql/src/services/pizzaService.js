import sql from 'mssql';
import configDB from '../models/db.js';
import Pizza from '../models/pizza.js';

export const getPizzas = async () => {
    const conn = await sql.connect(configDB);
    const results = await conn.request().query('SELECT * FROM Pizzas');

    console.log(results);
}
export const UpdatePizza= async() =>
{ const conn = await sql.connect(configDB);
    const pizza = new Pizza();
    pizza.nombre= "asasas"
    pizza.descripcion = "aaa";
    pizza.precio = 1000;
    pizza.libreDeGluten = false;
    const results= await conn.request()
    .input("pNombre", pizza.nombre)
    .input("pDescripcion", pizza.descripcion)
    .input("pLibreDeGluten", pizza.libreDeGluten)
    .input("pPrecio", pizza.precio)
    .query('INSERT INTO Pizzas(Nombre, Descripcion, Importe, LibreGluten) VALUES (@pNombre, @pDescripcion, @pPrecio, @pLibreDeGluten)');
    console.log(results);

}

