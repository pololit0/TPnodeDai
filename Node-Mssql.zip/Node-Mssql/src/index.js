import Pizza from "./models/pizza.js";
import  express  from "express";
import { CreatePizza,UpdatePizza,getPizzas,getPizzasById,DeletePizzas } from "./services/pizzaService.js";

const pizza = new Pizza();
pizza.nombre= "asaasasassas"
pizza.descripcion = "aalalala";
pizza.precio = 100200;
pizza.libreDeGluten = true;

const app = express();
const port = 3000;

app.use(express.json());

app.post('/api/Create', async (req,res)=>{

    const pizza = new Pizza();

    pizza.nombre = req.body.nombre
    pizza.descripcion =req.body.descripcion
    pizza.libreDeGluten=req.body.LibreDeGluten
    pizza.precio = req.body.precio
    const CrearPizza= await CreatePizza(pizza)
    res.status(201).json(CrearPizza);
})

app.put('/api/:id', async (req,res)=>{
    const id = req.params.id
    console.log(id)
    if(id >=0)
    {
        const pizza = await getPizzasById(id);

        pizza.nombre = req.body.nombre
        pizza.descripcion =req.body.descripcion
        pizza.libreDeGluten=req.body.LibreDeGluten
        pizza.precio = req.body.precio
        const Update= await UpdatePizza(pizza,id)
        
        res.status(200).json(Update);
    } else
    {
        res.status(400)
    }
   
 
})


app.get('/api/:id', async (req,res)=>{
    if (req.params.id > 0)
    {
        const pizza = await (getPizzasById(req.params.id))
        res.status(200).json(pizza)
    } else{

        res.status(400).send()
    }

})

app.get('/api', async (req,res)=>{
    const pizza = await (getPizzas(req.params.id))
    res.status(200).json(pizza)
   })

   app.delete('/api/:id', async (req,res)=>{
     if(req.params.id >=0)  {
        if(getPizzasById(req.params.id) !=null )
        {
            const pizza = await (DeletePizzas(req.params.id))
            res.status(200).json(pizza)
        } else
        {
               res.status(404).send()
        }
     } else
     {
        res.status(400).send()
     }

   
   })


app.listen(port, ()=>{

    console.log('puerto: ${port}')
})