import  {UpdatePizza, getPizzas}  from "./services/pizzaService.js";
await getPizzas();
await UpdatePizza();